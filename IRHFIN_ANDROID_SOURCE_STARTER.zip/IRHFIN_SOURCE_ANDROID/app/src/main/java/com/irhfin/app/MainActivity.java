package com.irhfin.app;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {
    private LinearLayout content;
    private int ink = Color.rgb(24, 48, 56);
    private int teal = Color.rgb(18, 110, 130);
    private int pale = Color.rgb(239, 247, 248);

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(Color.rgb(11,53,64));
        getWindow().setNavigationBarColor(Color.rgb(11,53,64));
        getWindow().getDecorView().setLayoutDirection(View.LAYOUT_DIRECTION_RTL);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.WHITE);

        TextView header = new TextView(this);
        header.setText("IRHFIN  |  ایر اچ فاین\nدرگاه هوشمند خدمات مالی و بانکی");
        header.setTextColor(Color.WHITE); header.setTextSize(21); header.setTypeface(null, Typeface.BOLD);
        header.setGravity(Gravity.RIGHT); header.setPadding(22,24,22,24); header.setBackgroundColor(Color.rgb(11,53,64));
        root.addView(header, new LinearLayout.LayoutParams(-1, -2));

        ScrollView scroll = new ScrollView(this);
        content = new LinearLayout(this); content.setOrientation(LinearLayout.VERTICAL); content.setPadding(18,18,18,24);
        scroll.addView(content); root.addView(scroll, new LinearLayout.LayoutParams(-1,0,1));
        setContentView(root);
        home();
    }

    private TextView text(String value, int size, boolean bold) {
        TextView t = new TextView(this); t.setText(value); t.setTextColor(ink); t.setTextSize(size);
        if (bold) t.setTypeface(null, Typeface.BOLD); t.setGravity(Gravity.RIGHT); t.setPadding(4,8,4,8); return t;
    }
    private void addButton(String label, Runnable action) {
        Button b = new Button(this); b.setText(label); b.setAllCaps(false); b.setTextColor(Color.WHITE); b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(teal));
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1,-2); p.setMargins(0,6,0,6); content.addView(b,p); b.setOnClickListener(v -> action.run());
    }
    private void reset(String title, String subtitle) {
        content.removeAllViews(); content.addView(text(title,22,true)); content.addView(text(subtitle,14,false));
    }
    private void home() {
        reset("ایده بزرگ، طراحی حساب‌شده، اجرای واقعی!", "نسخه اولیه نمایشی IRHFIN — خدمات اطلاعاتی و ابزارهای عمومی مالی");
        String[] names = {"خدمات مالی ایران", "خدمات مالی بین‌المللی", "کارت‌ها و روش‌های پرداخت", "وام و محاسبه اقساط", "پس‌انداز و سرمایه‌گذاری", "بیمه", "آموزش سواد مالی", "جست‌وجو و مقایسه", "علاقه‌مندی‌ها و حساب کاربری", "HAMED AI | دستیار هوشمند"};
        for (String n : names) addButton(n, () -> section(n));
        content.addView(text("توجه: این نسخه آزمایشی است و به بانک یا سامانه پرداخت متصل نیست. هیچ رمز بانکی، شماره کارت یا اطلاعات محرمانه وارد نکنید.",13,false));
    }
    private void section(String name) {
        if (name.contains("HAMED AI")) { ai(); return; }
        reset(name, "محتوای نمونه برای نسخه اولیه. اطلاعات خدمات باید پیش از انتشار از منابع معتبر بررسی و به‌روز شوند.");
        if (name.contains("اقساط")) {
            EditText amount = new EditText(this); amount.setHint("مبلغ وام (تومان)"); amount.setInputType(2); content.addView(amount);
            EditText rate = new EditText(this); rate.setHint("نرخ سود سالانه (درصد)"); rate.setInputType(8194); content.addView(rate);
            EditText months = new EditText(this); months.setHint("تعداد ماه بازپرداخت"); months.setInputType(2); content.addView(months);
            addButton("محاسبه تقریبی قسط", () -> {
                try {
                    double principal = Double.parseDouble(amount.getText().toString());
                    double annual = Double.parseDouble(rate.getText().toString()) / 1200.0;
                    int n = Integer.parseInt(months.getText().toString());
                    if (principal <= 0 || n <= 0 || annual < 0) throw new Exception();
                    double pay = annual == 0 ? principal/n : principal*annual*Math.pow(1+annual,n)/(Math.pow(1+annual,n)-1);
                    content.addView(text("قسط ماهانه تقریبی: " + String.format(java.util.Locale.US,"%,.0f",pay) + " تومان\nاین محاسبه تخمینی است و کارمزدها را لحاظ نمی‌کند.",17,true));
                } catch (Exception e) { Toast.makeText(this,"مبلغ، نرخ و مدت را درست وارد کنید.",Toast.LENGTH_LONG).show(); }
            });
        } else {
            content.addView(text("در این بخش، فهرست خدمات، منبع رسمی، تاریخ آخرین بررسی و شرایط استفاده نمایش داده خواهد شد.",16,false));
            addButton("جست‌وجوی خدمات", () -> search());
            addButton("بازگشت به خانه", () -> home());
        }
    }
    private void search() {
        reset("جست‌وجو و مقایسه", "در نسخه نمایشی، جست‌وجو محلی است و هنوز به پایگاه داده وصل نشده.");
        EditText q = new EditText(this); q.setHint("نام بانک، خدمت یا موضوع مالی"); content.addView(q);
        addButton("جست‌وجو", () -> Toast.makeText(this,"اتصال جست‌وجوی واقعی در مرحله سرور اضافه می‌شود.",Toast.LENGTH_LONG).show());
        addButton("خانه", () -> home());
    }
    private void ai() {
        reset("HAMED AI", "دستیار مالی فارسی — در این نسخه پاسخ‌ها نمایشی‌اند و موتور هوش مصنوعی واقعی متصل نیست.");
        EditText prompt = new EditText(this); prompt.setHint("پرسش عمومی مالی خود را بنویسید"); prompt.setMinLines(2); content.addView(prompt);
        addButton("ارسال پرسش", () -> {
            String q = prompt.getText().toString().trim();
            if (q.isEmpty()) { Toast.makeText(this,"ابتدا پرسش را بنویسید.",Toast.LENGTH_SHORT).show(); return; }
            content.addView(text("پاسخ نمایشی: برای تصمیم مالی، شرایط را از منبع رسمی بررسی کنید. برای اتصال پاسخ‌گویی واقعی باید API امن سمت سرور راه‌اندازی شود.",15,false));
        });
        addButton("بازگشت به خانه", () -> home());
    }
}
