-- IRHFIN core schema. Review and run only in the intended Supabase project.
-- Never place service_role keys in Android or client-side code.
create extension if not exists pgcrypto;

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  display_name text check (char_length(display_name) <= 120),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.user_roles (
  user_id uuid not null references auth.users(id) on delete cascade,
  role text not null check (role in ('user','content_operator','admin','security_auditor')),
  created_at timestamptz not null default now(),
  granted_by uuid references auth.users(id),
  primary key (user_id, role)
);

create table if not exists public.favorites (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  service_key text not null check (char_length(service_key) <= 160),
  created_at timestamptz not null default now(),
  unique (user_id, service_key)
);

create table if not exists public.financial_services (
  id uuid primary key default gen_random_uuid(),
  service_key text unique not null,
  name text not null,
  category text not null,
  country_code text not null default 'XX',
  description text not null default '',
  official_url text,
  verification_status text not null default 'unverified'
    check (verification_status in ('unverified','verified','needs_review','reported')),
  source_name text,
  source_checked_at timestamptz,
  is_published boolean not null default false,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.security_audit_log (
  id bigint generated always as identity primary key,
  actor_user_id uuid references auth.users(id) on delete set null,
  event_type text not null,
  target_type text,
  target_id text,
  outcome text not null check (outcome in ('success','denied','failure')),
  details jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now()
);

create or replace function public.irhfin_is_admin()
returns boolean language sql stable security definer
set search_path = '' as $$
  select exists (
    select 1 from public.user_roles r
    where r.user_id = (select auth.uid()) and r.role in ('admin','security_auditor')
  );
$$;

create or replace function public.irhfin_is_content_operator()
returns boolean language sql stable security definer
set search_path = '' as $$
  select exists (
    select 1 from public.user_roles r
    where r.user_id = (select auth.uid()) and r.role in ('admin','content_operator')
  );
$$;

alter table public.profiles enable row level security;
alter table public.user_roles enable row level security;
alter table public.favorites enable row level security;
alter table public.financial_services enable row level security;
alter table public.security_audit_log enable row level security;

-- Re-runnable policies
 drop policy if exists "profiles_select_own" on public.profiles;
 create policy "profiles_select_own" on public.profiles for select to authenticated using (id = (select auth.uid()));
 drop policy if exists "profiles_insert_own" on public.profiles;
 create policy "profiles_insert_own" on public.profiles for insert to authenticated with check (id = (select auth.uid()));
 drop policy if exists "profiles_update_own" on public.profiles;
 create policy "profiles_update_own" on public.profiles for update to authenticated using (id = (select auth.uid())) with check (id = (select auth.uid()));

 drop policy if exists "roles_select_own_or_admin" on public.user_roles;
 create policy "roles_select_own_or_admin" on public.user_roles for select to authenticated using (user_id = (select auth.uid()) or public.irhfin_is_admin());
 -- Intentionally no client INSERT/UPDATE/DELETE policies on user_roles. Grant roles through a trusted admin-only server process.

 drop policy if exists "favorites_read_own" on public.favorites;
 create policy "favorites_read_own" on public.favorites for select to authenticated using (user_id = (select auth.uid()));
 drop policy if exists "favorites_insert_own" on public.favorites;
 create policy "favorites_insert_own" on public.favorites for insert to authenticated with check (user_id = (select auth.uid()));
 drop policy if exists "favorites_delete_own" on public.favorites;
 create policy "favorites_delete_own" on public.favorites for delete to authenticated using (user_id = (select auth.uid()));

 drop policy if exists "services_public_read_published" on public.financial_services;
 create policy "services_public_read_published" on public.financial_services for select to anon, authenticated using (is_published = true or public.irhfin_is_content_operator());
 drop policy if exists "services_insert_operator" on public.financial_services;
 create policy "services_insert_operator" on public.financial_services for insert to authenticated with check (public.irhfin_is_content_operator());
 drop policy if exists "services_update_operator" on public.financial_services;
 create policy "services_update_operator" on public.financial_services for update to authenticated using (public.irhfin_is_content_operator()) with check (public.irhfin_is_content_operator());
 drop policy if exists "services_delete_admin" on public.financial_services;
 create policy "services_delete_admin" on public.financial_services for delete to authenticated using (public.irhfin_is_admin());

 drop policy if exists "audit_admin_read" on public.security_audit_log;
 create policy "audit_admin_read" on public.security_audit_log for select to authenticated using (public.irhfin_is_admin());
 -- No client insert/update/delete policy for audit rows. Write audit events from trusted server-side code.

 grant select, insert, update on public.profiles to authenticated;
 grant select on public.user_roles to authenticated;
 grant select, insert, delete on public.favorites to authenticated;
 grant select on public.financial_services to anon, authenticated;
 grant insert, update on public.financial_services to authenticated;
 grant delete on public.financial_services to authenticated;
 grant select on public.security_audit_log to authenticated;

-- Important: first admin must be assigned through Supabase SQL Editor or a trusted server process
-- after verifying the intended user's auth UUID. Do not add an admin grant endpoint to the public client.
