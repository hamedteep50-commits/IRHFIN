// Deploy with Supabase Edge Functions after setting OPENAI_API_KEY as a server secret.
// JWT verification must remain enabled. Never put OPENAI_API_KEY in Android.
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": Deno.env.get("IRHFIN_ALLOWED_ORIGIN") ?? "null",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
  "Content-Type": "application/json; charset=utf-8",
};

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: corsHeaders });
  if (req.method !== "POST") return new Response(JSON.stringify({ error: "method_not_allowed" }), { status: 405, headers: corsHeaders });
  const authHeader = req.headers.get("Authorization");
  if (!authHeader?.startsWith("Bearer ")) return new Response(JSON.stringify({ error: "unauthorized" }), { status: 401, headers: corsHeaders });

  const supabaseUrl = Deno.env.get("SUPABASE_URL");
  const anonKey = Deno.env.get("SUPABASE_ANON_KEY");
  const openAiKey = Deno.env.get("OPENAI_API_KEY");
  if (!supabaseUrl || !anonKey || !openAiKey) return new Response(JSON.stringify({ error: "server_not_configured" }), { status: 503, headers: corsHeaders });

  const supabase = createClient(supabaseUrl, anonKey, { global: { headers: { Authorization: authHeader } } });
  const { data: { user }, error: authError } = await supabase.auth.getUser();
  if (authError || !user) return new Response(JSON.stringify({ error: "unauthorized" }), { status: 401, headers: corsHeaders });

  let body: { message?: unknown };
  try { body = await req.json(); } catch { return new Response(JSON.stringify({ error: "invalid_json" }), { status: 400, headers: corsHeaders }); }
  if (typeof body.message !== "string" || body.message.trim().length < 1 || body.message.length > 4000) {
    return new Response(JSON.stringify({ error: "message_must_be_1_to_4000_chars" }), { status: 400, headers: corsHeaders });
  }

  // Production checklist: add per-user/IP rate limiting, budget controls, monitoring and a reviewed retention policy.
  const upstream = await fetch("https://api.openai.com/v1/responses", {
    method: "POST",
    headers: { "Authorization": `Bearer ${openAiKey}`, "Content-Type": "application/json" },
    body: JSON.stringify({
      model: Deno.env.get("OPENAI_MODEL") ?? "gpt-4.1-mini",
      instructions: "تو دستیار فارسی IRHFIN هستی. اطلاعات عمومی ارائه کن؛ درباره نرخ یا مقررات زنده ادعا نکن مگر منبع معتبر در ورودی باشد. رمز بانکی، CVV، رمز پویا، کلید خصوصی یا عبارت بازیابی درخواست نکن. برای تصمیم‌های مالی مهم توصیه کن منبع رسمی بررسی شود. پاسخ را به فارسی بده.",
      input: body.message.trim(),
      max_output_tokens: 700,
    }),
  });
  const payload = await upstream.json().catch(() => ({}));
  if (!upstream.ok) return new Response(JSON.stringify({ error: "ai_provider_error" }), { status: 502, headers: corsHeaders });
  const output = (payload.output ?? []).flatMap((item: any) => item.content ?? []).filter((item: any) => item.type === "output_text").map((item: any) => item.text).join("\n");
  return new Response(JSON.stringify({ answer: output || "پاسخی دریافت نشد.", request_id: payload.id ?? null }), { status: 200, headers: corsHeaders });
});
